kovbasa.com by zabka24k

Привет это мой сайт (эго не нужно вводить в браузере.)

Чтоб эго открыть нажми на mytoys.html он откроеться в браузере.не удаляй mytoys.jpg это фото.

так и с другими фото.

Сайт будет обновляться.




english:
kovbasa.com by zabka24k

Hello, this is my website.

(You don't need to type it into your browser.)

To open it, double-click on "mytoys.html". It will open in your browser.

Please do not delete "mytoys.jpg" — it is an image used by the website.

The same applies to any other images in this folder.

This website will be updated.
